public class FirstJavaProgram {
   public static void main(String[] args) {
       System.out.println("My name is Karis Hanson");
       System.out.println("I am 30 years old");
       System.out.println("My hometown is Bainbridge Island, WA");
   }
}
